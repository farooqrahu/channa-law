import { Cartitem } from './cartitem.model';

describe('Cartitem', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new Cartitem()).toBeTruthy();
  });
});
