import { Cartrequest } from './cartrequest.model';

describe('Cartrequest', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new Cartrequest()).toBeTruthy();
  });
});
