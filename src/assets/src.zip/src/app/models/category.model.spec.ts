import { Category } from './category.model';

describe('Category', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new Category()).toBeTruthy();
  });
});
