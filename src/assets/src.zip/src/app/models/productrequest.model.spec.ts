import { ProductRequest } from './productrequest.model';

describe('ProductRequest', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new ProductRequest()).toBeTruthy();
  });
});
