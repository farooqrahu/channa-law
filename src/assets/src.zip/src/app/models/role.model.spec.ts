import { Role } from './role.model';

describe('Role', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new Role()).toBeTruthy();
  });
});
