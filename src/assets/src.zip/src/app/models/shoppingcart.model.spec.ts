import { Shoppingcart } from './shoppingcart.model';

describe('Shoppingcart', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new Shoppingcart()).toBeTruthy();
  });
});
